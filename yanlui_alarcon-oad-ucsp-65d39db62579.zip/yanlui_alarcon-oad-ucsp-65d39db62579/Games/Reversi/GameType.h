//
// Created by yanlu on 12/3/2015.
//

#ifndef GAMES_GAMETYPE_H
#define GAMES_GAMETYPE_H


enum GameType { GAME_UNKNOWN, GAME_TICTACTOE, GAME_REVERSI };

#endif //GAMETYPE_H