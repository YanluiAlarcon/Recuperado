#include "Rand.h"

