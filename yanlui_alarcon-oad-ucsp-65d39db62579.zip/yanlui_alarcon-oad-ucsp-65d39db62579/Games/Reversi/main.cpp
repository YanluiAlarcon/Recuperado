#include <iostream>
#include "Reversi.h"

using namespace std;

int main()
{
    cout << "Hello world!" << endl;
    Reversi mat();

    return 0;
}
